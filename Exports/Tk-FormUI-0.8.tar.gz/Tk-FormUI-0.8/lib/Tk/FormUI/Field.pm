package Tk::FormUI::Field;
##----------------------------------------------------------------------------
## :mode=perl:indentSize=2:tabSize=2:noTabs=true:
##****************************************************************************
##****************************************************************************
## NOTES:
##  * Before comitting this file to the repository, ensure Perl Critic can be
##    invoked at the HARSH [3] level with no errors
##****************************************************************************

=head1 NAME

Tk::FormUI::Field - A role common to all form fields

=head1 VERSION

Version 0.1

=head1 SYNOPSIS


=cut

##****************************************************************************
##****************************************************************************
use Moo::Role;
## Moo enables strictures
## no critic (TestingAndDebugging::RequireUseStrict)
## no critic (TestingAndDebugging::RequireUseWarnings)
use Readonly;
use Carp qw(confess);

## Version string
our $VERSION = qq{0.1};


##****************************************************************************
## Object attribute
##****************************************************************************

=head1 ATTRIBUTES

=cut

##****************************************************************************
##****************************************************************************

=head2 key

=over 2

=item B<Description>

The hash key used when returning data from this field

=back

=cut

##----------------------------------------------------------------------------
has key => (
  is => qq{rw},
  required => 1,
);

##****************************************************************************
##****************************************************************************

=head2 label

=over 2

=item B<Description>

The label displayed for the field in the dialog

=back

=cut

##----------------------------------------------------------------------------
has label => (
  is => qq{rw},
  required => 1,
);

##****************************************************************************
##****************************************************************************

=head2 type

=over 2

=item B<Description>

The type of field

=back

=cut

##----------------------------------------------------------------------------
has type => (
  is => qq{rw},
  required => 1,
);

##****************************************************************************
##****************************************************************************

=head2 default

=over 2

=item B<Description>

The default or initial value of the field

=back

=cut

##----------------------------------------------------------------------------
has default => (
  is => qq{rw},
);

##****************************************************************************
##****************************************************************************

=head2 widget

=over 2

=item B<Description>

The Tk widget associated with this field

=back

=cut

##----------------------------------------------------------------------------
has widget => (
  is => qq{rwp},
);

##****************************************************************************
##****************************************************************************

=head2 label_font

=over 2

=item B<Description>

The font to use for the field's label

=item B<Default>

'times 12 bold'

=back

=cut

##----------------------------------------------------------------------------
has label_font => (
  is => qq{rw},
  default => qq{times 12 bold},
);

##****************************************************************************
##****************************************************************************

=head2 font

=over 2

=item B<Description>

The font to use for the field's widget

=item B<Default>

'times 12 bold'

=back

=cut

##----------------------------------------------------------------------------
has font => (
  is => qq{rw},
  default => qq{times 12},
);
##****************************************************************************
##****************************************************************************

=head2 readonly

=over 2

=item B<Description>

Indicates if the field is read only

=back

=cut

##----------------------------------------------------------------------------
has readonly => (
  is => qq{rw},
  default => 0,
);

##****************************************************************************
##****************************************************************************

=head2 width

=over 2

=item B<Description>

The width of the field

=back

=cut

##----------------------------------------------------------------------------
has width => (
  is => qq{rw},
  required => 1,
  default => 40,
);

##****************************************************************************
## Object Methods
##****************************************************************************

=head1 METHODS

=cut

##****************************************************************************
##****************************************************************************

=head2 is_type($type)

=over 2

=item B<Description>

Returns 1 if the field is the specified type

=item B<Parameters>

BOOLEAN indicating if the field is the specified type

=item B<Return>

1 if the field is the specified type otherwise 0

=back

=cut

##----------------------------------------------------------------------------
sub is_type
{
  my $self = shift;
  my $type = shift;
  
  return ((uc($self->type) eq uc($type)) ? 1 : 0);
}

##****************************************************************************
##****************************************************************************

=head2 build_label($parent)

=over 2

=item B<Description>

Build the label widget for the field

=item B<Parameters>

$parent - Parent widget

=item B<Return>

widget object

=back

=cut

##----------------------------------------------------------------------------
sub build_label
{
  my $self   = shift;
  my $parent = shift;

  ## Create the label
  my $label = $parent->Label(
    -text   => $self->label . qq{: },
    -font   => $self->label_font,
    -anchor => qq{e},
  );
  
  return($label);
}

##****************************************************************************
##****************************************************************************

=head2 build_widget($parent)

=over 2

=item B<Description>

Build the widget associated with this field.
NOTE: This method should be overridden in the class for the field!

=item B<Parameters>

$parent - Parent widget for this widget

=item B<Return>

Widget object

=back

=cut

##----------------------------------------------------------------------------
sub build_widget
{
  my $self   = shift;
  
  ## Set our widget
  $self->_set_widget(undef);

  return;
}


##****************************************************************************
## Additional POD documentation
##****************************************************************************

=head1 AUTHOR

Paul Durden E<lt>alabamapaul AT gmail.comE<gt>

=head1 COPYRIGHT & LICENSE

Copyright (C) 2015 by Paul Durden.

This program is free software; you can redistribute it and/or modify it
under the same terms as Perl itself.

=cut

1;    ## End of module
__END__

